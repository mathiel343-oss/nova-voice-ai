<?php
declare(strict_types=1);

// NVIDIA NIM API — OpenAI-compatible
define('AI_API_KEY',  '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');
define('AI_BASE_URL', 'https://integrate.api.nvidia.com/v1');
define('AI_MODEL',    'z-ai/glm-5.2');

define('APP_DEBUG', true); 
