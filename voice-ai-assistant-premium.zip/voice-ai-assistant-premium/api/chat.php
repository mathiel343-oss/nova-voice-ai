<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

require_once dirname(__DIR__) . '/config.php';

function sendJson(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ─── التحقق من الطلب ────────────────────────────────────────────────────────
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    sendJson(405, ['success' => false, 'error' => ['code' => 'METHOD_NOT_ALLOWED', 'message' => 'يسمح بطلبات POST فقط.']]);
}
if (!function_exists('curl_init')) {
    sendJson(500, ['success' => false, 'error' => ['code' => 'CURL_MISSING', 'message' => 'إضافة cURL غير مفعلة في PHP.']]);
}

$input = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($input)) {
    sendJson(400, ['success' => false, 'error' => ['code' => 'INVALID_JSON', 'message' => 'صيغة JSON المرسلة غير صالحة.']]);
}

$prompt   = trim((string)($input['prompt']   ?? ''));
$language = (string)($input['language'] ?? 'ar-SA');
$history  = is_array($input['history'] ?? null) ? $input['history'] : [];

if ($prompt === '') {
    sendJson(400, ['success' => false, 'error' => ['code' => 'EMPTY_PROMPT', 'message' => 'الرجاء إرسال نص صالح.']]);
}

$length = function_exists('mb_strlen') ? mb_strlen($prompt, 'UTF-8') : strlen($prompt);
if ($length > 4000) {
    sendJson(413, ['success' => false, 'error' => ['code' => 'PROMPT_TOO_LONG', 'message' => 'النص طويل جدًا. الحد الأقصى 4000 حرف.']]);
}

// ─── قراءة الإعدادات ─────────────────────────────────────────────────────────
$apiKey  = defined('AI_API_KEY')  ? trim((string)AI_API_KEY)  : '';
$baseUrl = defined('AI_BASE_URL') ? trim((string)AI_BASE_URL) : '';
$model   = defined('AI_MODEL')    ? trim((string)AI_MODEL)    : '';
$debug   = defined('APP_DEBUG')   && APP_DEBUG === true;

if ($apiKey === '' || str_contains($apiKey, 'PUT_YOUR_')) {
    sendJson(500, ['success' => false, 'error' => ['code' => 'API_KEY_MISSING', 'message' => 'أضف مفتاح AI API داخل config.php.']]);
}
if ($model === '' || str_contains($model, 'PUT_YOUR_')) {
    sendJson(500, ['success' => false, 'error' => ['code' => 'MODEL_MISSING', 'message' => 'أضف اسم النموذج داخل config.php.']]);
}

// ─── بناء سجل المحادثة بصيغة OpenAI ─────────────────────────────────────────
$systemText = $language === 'en-US'
    ? 'You are NOVA, a professional voice AI assistant. Respond in the user language. Be accurate, helpful, clear, and concise. Use structured formatting when useful.'
    : 'أنت NOVA، مساعد صوتي ذكي واحترافي. أجب باللغة التي يستخدمها المستخدم. كن دقيقًا ومفيدًا وواضحًا ومختصرًا، واستخدم تنسيقًا منظمًا عند الحاجة.';

$messages = [['role' => 'system', 'content' => $systemText]];

foreach (array_slice($history, -10) as $item) {
    if (!is_array($item)) continue;
    $text = trim((string)($item['text'] ?? ''));
    if ($text === '') continue;
    $role = ($item['role'] ?? '') === 'bot' ? 'assistant' : 'user';
    $safeText = function_exists('mb_substr') ? mb_substr($text, 0, 2000, 'UTF-8') : substr($text, 0, 2000);
    $messages[] = ['role' => $role, 'content' => $safeText];
}
$messages[] = ['role' => 'user', 'content' => $prompt];

// ─── بناء جسم الطلب (OpenAI-compatible) ──────────────────────────────────────
$requestBody = json_encode([
    'model'       => $model,
    'messages'    => $messages,
    'temperature' => 0.65,
    'max_tokens'  => 900,
    'top_p'       => 0.9,
    'stream'      => false,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

if ($requestBody === false) {
    sendJson(500, ['success' => false, 'error' => ['code' => 'JSON_ENCODE_FAILED', 'message' => 'تعذر تجهيز الطلب.']]);
}

// ─── إرسال الطلب عبر cURL ────────────────────────────────────────────────────
$url = rtrim($baseUrl, '/') . '/chat/completions';
$ch  = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . $apiKey,
    ],
    CURLOPT_POSTFIELDS     => $requestBody,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT        => 60,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => 0,
]);

$response  = curl_exec($ch);
$httpCode  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// ─── معالجة الاستجابة ────────────────────────────────────────────────────────
if ($response === false) {
    sendJson(502, ['success' => false, 'error' => [
        'code'    => 'UPSTREAM_CONNECTION_FAILED',
        'message' => 'فشل اتصال PHP بخدمة AI API.',
        'details' => $debug ? $curlError : null,
    ]]);
}

$data = json_decode((string)$response, true);
if (!is_array($data)) {
    sendJson(502, ['success' => false, 'error' => [
        'code'    => 'INVALID_UPSTREAM_RESPONSE',
        'message' => 'أعادت خدمة AI استجابة غير صالحة.',
        'details' => $debug ? $response : null,
    ]]);
}

if ($httpCode < 200 || $httpCode >= 300) {
    $message = (string)($data['error']['message'] ?? 'رفضت خدمة AI الطلب.');
    sendJson(502, ['success' => false, 'error' => [
        'code'            => 'UPSTREAM_REJECTED',
        'message'         => $debug ? $message : 'رفضت خدمة AI الطلب. تحقق من المفتاح والنموذج.',
        'upstream_status' => $httpCode,
    ]]);
}

// ─── استخراج الرد (OpenAI format) ────────────────────────────────────────────
$reply = trim((string)($data['choices'][0]['message']['content'] ?? ''));

if ($reply === '') {
    sendJson(502, ['success' => false, 'error' => ['code' => 'EMPTY_AI_REPLY', 'message' => 'لم تُرجع خدمة AI ردًا نصيًا.']]);
}

sendJson(200, [
    'success' => true,
    'reply'   => $reply,
    'model'   => $data['model'] ?? $model,
    'usage'   => $data['usage'] ?? null,
]);
