<?php
declare(strict_types=1);

// أضف بياناتك المحلية هنا. هذا الملف موجود داخل .gitignore.
define('GEMINI_API_KEY', 'AQ.Ab8RN6LjbJ7mb081Eu9rFHuAjQ24ynuIyROer5lLuCgKhVY31Q');
define('GEMINI_MODEL', 'gemini-3.6-flash');

define('APP_DEBUG', true); // غيّرها إلى false قبل نشر المشروع.
