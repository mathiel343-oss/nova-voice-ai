<?php
declare(strict_types=1);

// ضع مفتاح Gemini الجديد واسم النموذج الذي يعمل مع حسابك.
define('GEMINI_API_KEY', 'PUT_YOUR_GEMINI_API_KEY_HERE');
define('GEMINI_MODEL', 'PUT_YOUR_AVAILABLE_GEMINI_MODEL_HERE');
define('APP_DEBUG', true); // اجعلها false قبل النشر العام.
