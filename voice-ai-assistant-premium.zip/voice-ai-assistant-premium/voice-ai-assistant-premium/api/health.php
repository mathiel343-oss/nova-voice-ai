<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once dirname(__DIR__) . '/config.php';

$key = defined('GEMINI_API_KEY') ? trim((string)GEMINI_API_KEY) : '';

http_response_code(200);
echo json_encode([
    'success' => true,
    'php_version' => PHP_VERSION,
    'curl_enabled' => function_exists('curl_init'),
    'mbstring_enabled' => function_exists('mb_strlen'),
    'api_key_configured' => $key !== '' && !str_contains($key, 'PUT_YOUR_'),
    'model' => defined('GEMINI_MODEL') ? GEMINI_MODEL : null,
    'debug' => defined('APP_DEBUG') && APP_DEBUG === true,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
