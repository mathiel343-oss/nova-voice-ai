# NOVA Voice-to-Voice AI Assistant

مشروع مساعد صوتي احترافي يعمل بثلاث مراحل:

1. **Speech-to-Text:** تحويل صوت المستخدم إلى نص عبر Web Speech API.
2. **LLM Processing:** إرسال النص من JavaScript إلى PHP ثم إلى Gemini API.
3. **Text-to-Speech:** تحويل رد Gemini إلى صوت عبر SpeechSynthesis.

## الإصلاحات الستة الجديدة

1. إصلاح الـLayout باستخدام CSS Grid و`minmax(0,1fr)` لمنع تمدد العناصر خارج الشاشة.
2. إضافة Scroll مستقل لمنطقة المحادثة وScroll مستقل للوحة الإعدادات.
3. تثبيت مربع الإدخال أسفل التطبيق مع تكبير تلقائي وحماية من تجاوز ارتفاع الشاشة.
4. إضافة فحص حقيقي للخادم عبر `api/health.php` بدل عرض Online بشكل شكلي.
5. ربط جميع الوظائف: الكتابة، الميكروفون، الإرسال، النطق، الإيقاف، النسخ، التصدير، المسح، المظهر واللغة.
6. إضافة Responsive UI: لوحة إعدادات جانبية تتحول إلى Drawer على الهاتف والتابلت.

## التشغيل على XAMPP

1. فك الضغط داخل:

```text
C:\xampp\htdocs\NOVA-Voice-Pro-Ready
```

2. افتح `config.php` وضع مفتاح Gemini واسم النموذج المتاح لحسابك.
3. شغّل Apache.
4. اختبر:

```text
http://localhost/NOVA-Voice-Pro-Ready/api/health.php
```

5. افتح التطبيق:

```text
http://localhost/NOVA-Voice-Pro-Ready/
```

لا تفتح `index.html` باستخدام `file:///` لأن PHP لن يعمل.

## إعداد config.php

```php
<?php
define('GEMINI_API_KEY', 'YOUR_API_KEY');
define('GEMINI_MODEL', 'YOUR_WORKING_MODEL');
define('APP_DEBUG', true);
```

بعد نجاح الاختبارات، غيّر `APP_DEBUG` إلى `false`.

## هيكل المشروع

```text
NOVA-Voice-Pro-Ready/
├── api/
│   ├── chat.php
│   └── health.php
├── assets/
│   ├── css/style.css
│   ├── js/app.js
│   └── icons/icon.svg
├── config.php
├── config.example.php
├── index.html
├── manifest.webmanifest
├── .htaccess
├── .gitignore
└── README.md
```

## GitHub

لا ترفع مفتاح API الحقيقي. اترك `config.php` داخل `.gitignore` وارفع `config.example.php`.

```bash
git init
git add .
git commit -m "Complete NOVA voice-to-voice assistant"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```
