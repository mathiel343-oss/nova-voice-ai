<?php
declare(strict_types=1);

// مثال على الإعدادات — انسخ هذا الملف باسم config.php وعدّل القيم.
// يدعم المشروع أي API متوافقة مع صيغة OpenAI (مثل NVIDIA NIM).
define('AI_API_KEY',  'PUT_YOUR_API_KEY_HERE');
define('AI_BASE_URL', 'https://integrate.api.nvidia.com/v1'); // أو أي endpoint متوافق
define('AI_MODEL',    'z-ai/glm-5.2');                        // اسم النموذج المراد استخدامه
define('APP_DEBUG', false); // اجعلها true أثناء التطوير فقط.
